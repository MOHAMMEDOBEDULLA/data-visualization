# Online Python compiler (interpreter) to run Python online.
# Write Python 3 code in this online editor and run it.
# Get started with interactive Python!
# Supports Python Modules: builtins, math,pandas, scipy 
# matplotlib.pyplot, numpy, operator, processing, pygal, random, 
# re, string, time, turtle, urllib.request
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib as mp

plt.figure(figsize=(8,6))
x = np.random.random(10)
y = np.random.random(10)
# "alpha" is used for softnening colors
plt.rcParams['text.color'] = 'red' # Label Color
plt.scatter(np.random.random(10),np.random.random(10),c='r', s=50 , alpha=0.6 , label = 'One' )
plt.scatter(np.random.random(10),np.random.random(10),c='b', s=100 , alpha=0.6 , label = 'Two')
plt.scatter(np.random.random(10),np.random.random(10),c='g', s=150 , alpha=0.6 , label = 'Three')
plt.scatter(np.random.random(10),np.random.random(10),c='y', s=200 , alpha=0.6 , label = 'Four')
plt.legend(bbox_to_anchor=(1.0, 1.0) , shadow=True, fontsize='x-large')
plt.show()
#age	sex	bmi	children	smoker	region	charges
#0	19	female	27.900	0	yes	southwest	16884.92400
#1	18	male	33.770	1	no	southeast	1725.55230
#2	28	male	33.000	3	no	southeast	4449.46200
#3	33	male	22.705	0	no	northwest	21984.47061
#4	32	male	28.880	0	no	northwest	3866.85520
# Plot the levels of the third variable across different columns
#sns.lmplot(x="bmi", y="charges", hue="smoker", col="sex", data=insurance ,height=6,aspect=1 )